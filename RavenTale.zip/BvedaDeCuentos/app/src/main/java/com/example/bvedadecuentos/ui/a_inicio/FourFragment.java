package com.example.bvedadecuentos.ui.a_inicio;


import static android.content.ContentValues.TAG;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.ui.relato;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class FourFragment extends Fragment {
    private listaRelatosAdapter adapter;
    private LinearLayoutManager linearLayoutManager;
    String messages;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recycler1);


        recyclerView.setHasFixedSize(true);
        //Cargar recyclerView Con datos
        linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);


        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference relatosRef = db.collection("relatos");
        ArrayList<DocumentSnapshot> documentos = new ArrayList<>();
        Drawable drawable = getResources().getDrawable(R.drawable.imagess);
        ArrayList<relato> relatosOrdenados = new ArrayList<>();

        Query query = relatosRef
                .whereEqualTo("estado", true); // ordenar por valoración de mayor a menor

        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@org.checkerframework.checker.nullness.qual.NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    // la consulta se ejecutó correctamente, recorre los documentos resultantes
                    System.out.println("ESTOY AQUI 1");
                    if (task.getResult().isEmpty()) {
                        System.out.println("Hay " + task.getResult().size() + " documentos que cumplen con el filtro.");
                    }

                    for (DocumentSnapshot document : task.getResult()) {
                        documentos.add(document);
                    }

                    Collections.sort(documentos, new Comparator<DocumentSnapshot>() {
                        @Override
                        public int compare(DocumentSnapshot d1, DocumentSnapshot d2) {
                            double puntuacion1 = d1.getDouble("puntuacion");
                            double puntuacion2 = d2.getDouble("puntuacion");
                            return Double.compare(puntuacion2, puntuacion1);
                        }
                    });

                    for (DocumentSnapshot document : documentos) {
                        String titulo = document.getString("titulo");
                        DocumentReference autorRef = document.getDocumentReference("autor");
                        String descripcion = document.getString("contenido");
                        double puntuacion = document.getDouble("puntuacion");
                        String formato = "#." + new String(new char[2]).replace('\0', '#');
                        DecimalFormat decimalFormat = new DecimalFormat(formato);
                        relato relato = new relato(titulo, autorRef.getPath(), descripcion, String.valueOf(decimalFormat.format(puntuacion)), puntuacion, drawable);
                        relatosOrdenados.add(relato);
                    }

                    // Crea y configura el adaptador y el RecyclerView con la lista de relatos ordenados

                    // haz lo que necesites con la lista de relatos del autor
                } else {
                    Log.d(TAG, "Error getting documents: ", task.getException());
                }
                adapter = new listaRelatosAdapter(relatosOrdenados, getContext());
                recyclerView.setAdapter(adapter);

            }
        });


        return view;
    }
}