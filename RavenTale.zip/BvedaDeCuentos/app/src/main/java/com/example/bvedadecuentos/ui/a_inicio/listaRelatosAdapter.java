package com.example.bvedadecuentos.ui.a_inicio;

import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.ui.b_proyectos.crearRelato;
import com.example.bvedadecuentos.ui.b_proyectos.listarRelatos;
import com.example.bvedadecuentos.ui.b_proyectos.myAdapter3;
import com.example.bvedadecuentos.ui.relato;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class listaRelatosAdapter extends RecyclerView.Adapter<listaRelatosAdapter.MyHolder>{

    private FirebaseFirestore db;
    private ArrayList<relato> listaRelatos = new ArrayList<>();
    String ultimoSegmento;
    private Context contexto;


    public listaRelatosAdapter(ArrayList<relato>arr, Context context){
        //FUNCIONA
        listaRelatos = arr;
        contexto = context;
        db = FirebaseFirestore.getInstance(); // Agregar esta línea
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(contexto).inflate(R.layout.activity_caps_list, parent, false);
        return new MyHolder(view);
    }


        @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.genero.setText(listaRelatos.get(position).getGenero());
            String titulo = listaRelatos.get(position).getTitulo();
            titulo = titulo.replaceAll(" ", "\n"); // Reemplazar espacios en blanco con saltos de línea
            holder.titulo.setText(titulo);        holder.portada.setImageDrawable(listaRelatos.get(position).getPortada());
            String autorId = listaRelatos.get(position).getAutor();
            String[] segmentos = autorId.split("/");
            ultimoSegmento = segmentos[segmentos.length - 1];
            DocumentReference autorRef = db.collection("autores").document(ultimoSegmento);
            autorRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                @Override
                public void onSuccess(DocumentSnapshot documentSnapshot) {
                    if (documentSnapshot.exists()) {
                        String nombreAutor = documentSnapshot.getString("Name");
                        holder.autor.setText(nombreAutor);
                    }
                }
            });

        holder.linearTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Crear menú emergente
                PopupMenu popup = new PopupMenu(holder.linearTotal.getContext(), holder.linearTotal);                System.out.println("POPUP");

                // Inflar menú desde archivo xml
                popup.getMenuInflater().inflate(R.menu.view, popup.getMenu());

                // Asignar listener a las opciones del menú
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        System.out.println("ANTES DEL SWITCH");
                        switch (item.getItemId()) {
                            case R.id.Leer:
                                // Acción para la opción 1
                                Intent intent = new Intent(contexto, lector.class);
                                intent.putExtra("titulo", listaRelatos.get(position).getTitulo());
                                intent.putExtra("autor", ultimoSegmento);

                                contexto.startActivity(intent);
                                //CAMBIAR A PENSTAÑA DE EDICION

                                break;

                            case R.id.Puntuar:
                                AlertDialog.Builder builder = new AlertDialog.Builder(contexto);
                                View dialogView = LayoutInflater.from(contexto).inflate(R.layout.puntuacion_dialog, null);
                                builder.setView(dialogView);

                                builder.setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        FirebaseFirestore db = FirebaseFirestore.getInstance();

// Obtener la puntuación del RatingBar y el texto del EditText
                                        RatingBar ratingBar = dialogView.findViewById(R.id.ratingBar);
                                        EditText comentarioEditText = dialogView.findViewById(R.id.opinionEditText);
                                        float puntuacion = ratingBar.getRating();
                                        String comentario = comentarioEditText.getText().toString();
                                        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                        DocumentReference autorRef = db.collection("autores").document(uid);
// Crear un objeto que contenga la puntuación y el comentario
                                        Map<String, Object> datos = new HashMap<>();
                                        datos.put("puntuacion", puntuacion);
                                        datos.put("comentario", comentario);
                                        datos.put("creador", autorRef);
                                        String relatoId = listaRelatos.get(position).getTitulo(); //Obtener el ID del relato seleccionado
                                        datos.put("relato", db.collection("relatos").document(relatoId));
                                        String AutorRelato = listaRelatos.get(position).getAutor(); //Obtener el ID del relato seleccionado
                                        datos.put("autorRelato", db.collection("autores").document(ultimoSegmento));
// Añadir los datos a la base de datos de Firebase
                                        db.collection("puntuaciones")
                                                .add(datos)
                                                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                                    @Override
                                                    public void onSuccess(DocumentReference documentReference) {
                                                        String relatoId = listaRelatos.get(position).getTitulo();

// Filtrar las puntuaciones correspondientes al relato seleccionado
                                                        db.collection("puntuaciones")
                                                                .whereEqualTo("relato", db.collection("relatos").document(relatoId))
                                                                .get()
                                                                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                                                    @Override
                                                                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                                                        // Calcular la puntuación promedio
                                                                        float puntuacionTotal = 0;
                                                                        int cantidadTotal = queryDocumentSnapshots.size();
                                                                        System.out.println(cantidadTotal+"ESTA ES CANTIDA TOTAL");
                                                                        for (DocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                                                                            double puntuacion = documentSnapshot.getDouble("puntuacion");
                                                                            puntuacionTotal += puntuacion;
                                                                        }
                                                                        double puntuacionPromedio = puntuacionTotal / cantidadTotal;
                                                                        System.out.println(puntuacionPromedio+"ESTA ES LA CANTIDAD PROMEDIO");

                                                                        FirebaseFirestore db = FirebaseFirestore.getInstance();
                                                                        DocumentReference autor = autorRef;
                                                                        String titulo = listaRelatos.get(position).getTitulo();

                                                                        db.collection("relatos")
                                                                                .whereEqualTo("autor", autor)
                                                                                .whereEqualTo("titulo", titulo)
                                                                                .get()
                                                                                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                                                                    @Override
                                                                                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                                                                        // Verificar si se encontró un documento que coincida con los criterios de búsqueda
                                                                                        if (!queryDocumentSnapshots.isEmpty()) {
                                                                                            // Obtener el primer documento de la lista (suponiendo que no hay documentos duplicados)
                                                                                            DocumentSnapshot relato = queryDocumentSnapshots.getDocuments().get(0);
                                                                                            String relatoId = relato.getId();

                                                                                            // Actualizar el documento del relato con la puntuación promedio
                                                                                            db.collection("relatos")
                                                                                                    .document(relatoId)
                                                                                                    .update("puntuacion", puntuacionPromedio)
                                                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                                        @Override
                                                                                                        public void onSuccess(Void aVoid) {
                                                                                                            // La puntuación del relato se ha actualizado correctamente en Firebase
                                                                                                        }
                                                                                                    })
                                                                                                    .addOnFailureListener(new OnFailureListener() {
                                                                                                        @Override
                                                                                                        public void onFailure(@NonNull Exception e) {
                                                                                                            // Se ha producido un error al actualizar la puntuación del relato en Firebase
                                                                                                        }
                                                                                                    });
                                                                                        } else {
                                                                                            // No se encontró ningún documento que coincida con los criterios de búsqueda
                                                                                        }
                                                                                    }
                                                                                })
                                                                                .addOnFailureListener(new OnFailureListener() {
                                                                                    @Override
                                                                                    public void onFailure(@NonNull Exception e) {
                                                                                        // Se ha producido un error al buscar el documento en Firebase
                                                                                    }
                                                                                });

                                                                    }
                                                                })
                                                                .addOnFailureListener(new OnFailureListener() {
                                                                    @Override
                                                                    public void onFailure(@NonNull Exception e) {
                                                                        // Se ha producido un error al obtener las puntuaciones del relato en Firebase
                                                                    }
                                                                });
                                                    }
                                                })
                                                .addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                        // Se ha producido un error al guardar la puntuación y el comentario en Firebase
                                                    }
                                                });
                                    }
                                });

                                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });

                                AlertDialog dialog = builder.create();
                                dialog.show();
                                break;




                            //case R.id.comentarios:
                             //   intent = new Intent(contexto, leercomentarios.class);
                              //  contexto.startActivity(intent);
                              //  break;
                        }


                        return true;
                    }
                });

                // Mostrar menú emergente
                popup.show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return listaRelatos.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder{
        TextView titulo;
        TextView genero;
        ImageView portada;
        TextView autor;
        LinearLayout linearTotal;

        public MyHolder (@NonNull View itemView){
            super(itemView);
            titulo = itemView.findViewById(R.id.textView16);
            genero = itemView.findViewById(R.id.textView17);
            portada = itemView.findViewById(R.id.imageView5);
            autor = itemView.findViewById(R.id.textview29);
            linearTotal = itemView.findViewById(R.id.linearTotal);
        }
    }
}