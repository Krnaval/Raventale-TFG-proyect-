package com.example.bvedadecuentos;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.Map;

public class login extends AppCompatActivity {

    private Button entrar;
    private EditText gmail, pass;
    private TextView registrarse;
    private FirebaseFirestore firebase = FirebaseFirestore.getInstance();
    private FirebaseAuth aut;
    boolean loginExitoso;
    public static final String LOGIN = "login";


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        System.out.println("AEEAEAEAAAAAAAA");
        super.onCreate(savedInstanceState);
        System.out.println("AEEAEAEAAAAAAAA");

        setContentView(R.layout.activity_login);
        System.out.println("AEEAEAEAAAAAAAA");
        SharedPreferences login = getSharedPreferences(LOGIN, Context.MODE_PRIVATE);
        getSupportActionBar().hide();

        entrar = findViewById(R.id.button);
        gmail = findViewById(R.id.editTextTextPersonName);
        pass = findViewById(R.id.editTextTextPersonName2);
        registrarse = findViewById(R.id.textView8);
        System.out.println("AEEAEAEAAAAAAAA");
        System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        System.out.println(login.getString("Gmail", null));
        System.out.println();
        System.out.println();
        gmail.setText(login.getString("Gmail", null));
        pass.setText(login.getString("Password", null));



        //Aquí comprobamos si ya se logeó alguna vez con este movil


        registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Cambio = new Intent(getApplicationContext(), registrarse.class);
                startActivity(Cambio);
            }
        });

        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (isComprobarLongitudError()) {
                    return;
                }
                //Aquí entramos en la base de datos y comprobamos, si existe dentro el usuario cambiamos las preferencias para que entre siempre con este
                comprobarrBaseDeDatosParaEntrarFalse();
                System.out.println("AEAEEA");




                System.out.println(loginExitoso);




            }

            //Metodo para comprobar la base de datos
            private void comprobarrBaseDeDatosParaEntrarFalse() {
                aut = FirebaseAuth.getInstance();
                aut.signInWithEmailAndPassword(gmail.getText().toString(), pass.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()){
                                    loginExitoso = true;
                                    //Llamamos al submetodo login
                                    login();
                                }else{
                                    loginExitoso = false;
                                    //Llamamos al submetodo login
                                    login();
                                }
                            }
                        });
            }

            private void login() {
                System.out.println(loginExitoso);
                //En caso de que el login sea exitoso
                if (loginExitoso){
                    //cambiamos al main
                    Intent Cambio = new Intent(getApplicationContext(), login_complete.class);
                    startActivity(Cambio);
                    Toast.makeText(getApplicationContext(), "¡Bienvenido al Nido!", Toast.LENGTH_SHORT).show();
                }else{
                    //Fallo
                    Toast.makeText(getApplicationContext(), "Error. Campos introducidos erroneos", Toast.LENGTH_LONG).show();
                }
            }


            private boolean isComprobarLongitudError() {
                if (pass.getText().length() < 6) {
                    pass.setError("Este campo tiene que ser mayor a 6 caracteres");
                    pass.requestFocus();
                    return true;
                } else if (pass.getText().length() > 12) {
                    pass.setError("Este campo tiene que ser menor a 12 caracteres");
                    pass.requestFocus();
                    return true;
                }
                pass.setError(null);
                return false;
            }

        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
    @Override
    public void onBackPressed() {
            super.finishAffinity();
        }

}