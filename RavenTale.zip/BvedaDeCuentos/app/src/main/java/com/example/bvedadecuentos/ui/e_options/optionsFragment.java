package com.example.bvedadecuentos.ui.e_options;

import static androidx.core.content.ContextCompat.getSystemService;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.databinding.FragmentOptionsBinding;
import com.example.bvedadecuentos.login;
import com.example.bvedadecuentos.ui.c_perfil.perfilFragment;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class optionsFragment extends Fragment {

    private Button Aceptar;
    private EditText name, descr;
    private FragmentOptionsBinding binding;
    private FirebaseFirestore firebase = FirebaseFirestore.getInstance();
    private FirebaseAuth aut;
    MediaPlayer md;

    public static final String LOGIN = "login";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentOptionsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        SharedPreferences login = getActivity().getSharedPreferences(LOGIN, Context.MODE_PRIVATE);
        md = MediaPlayer.create(getContext(), R.raw.buttonsound);

        Aceptar = root.findViewById(R.id.button3);

        descr = root.findViewById(R.id.edit_text);
        name = root.findViewById(R.id.edit_text2);
        System.out.println(descr.getText().toString());


        descr.setText(login.getString("Descr", null));
        name.setText(login.getString("Name", null));
        System.out.println(descr.getText().toString());





        Aceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("VOY");
                boolean c = name.getText().toString().isEmpty();
                System.out.println(c);
                System.out.println(descr.getText().toString());

                if ((name.getText().toString().isEmpty())){
                    System.out.println("ENTRO");

                    name.setError("Este campo tiene que tener contenido");
                    name.requestFocus();
                    return;
                }

                if (name.getText().toString().contains(" ")){
                    System.out.println(name.getText());
                    name.setError("Este campo no puede tener espacios");
                    name.requestFocus();
                }

                System.out.println("SALGO");

                CollectionReference usuariosRef = firebase.collection("autores");
                login.edit().putString("Descr", descr.getText().toString()).apply();
                login.edit().putString("Name", name.getText().toString()).apply();



                //Guardamos los datos en la base de datos
                Toast.makeText(getContext(), "Datos cambiados correctamente", Toast.LENGTH_SHORT).show();
                Map<String, Object> datosUsuario = new HashMap<>();
                datosUsuario.put("Name", name.getText().toString());
                datosUsuario.put("descripcion", descr.getText().toString());
                FirebaseAuth auth = FirebaseAuth.getInstance();
                FirebaseUser user = auth.getCurrentUser();
                String userId = "";
                if (user != null) {
                    // El usuario está autenticado
                     userId = user.getUid();
                    // ...
                } else {
                    // El usuario no está autenticado
                    // ...
                }
                usuariosRef.document(userId).update(datosUsuario)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                // Datos actualizados correctamente
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                // Error al actualizar los datos
                            }
                        });

                //Mostramos la nueva descripción y el nuevo nombre
                descr.setText(login.getString("Descr", null));
                name.setText(login.getString("Name", null));



            }

        });
        comprobarSonido();


        return root;

    }

    @Override
    public void onResume() {
        super.onResume();

        // Refrescamos los datos del perfil
        SharedPreferences login = getActivity().getSharedPreferences(LOGIN, Context.MODE_PRIVATE);
        name.setText(login.getString("Name", "No se carga bien el usu"));
        descr.setText(login.getString("Descr", ""));
        System.out.println(descr.getText().toString());

    }

    private void comprobarSonido(){
        if (md != null){
            md.stop();
            try {
                md.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        md.start();
    }
}
