package com.example.bvedadecuentos.ui.b_proyectos;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.databinding.FragmentProyectosBinding;

import java.io.IOException;

public class proyectoFragment extends Fragment {

    private FragmentProyectosBinding binding;
    private Button Escribir, seguirEscribiendo, adjuntar;
    MediaPlayer md;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentProyectosBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        md = MediaPlayer.create(getContext(), R.raw.buttonsound);
        Escribir = root.findViewById(R.id.button4);
        seguirEscribiendo = root.findViewById(R.id.button2);
        adjuntar = root.findViewById(R.id.button3);
        comprobarSonido();
        Escribir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity().getApplicationContext(), crearRelato.class);
                startActivity(intent);
            }
        });

        seguirEscribiendo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity().getApplicationContext(), listarRelatos.class);
                intent.putExtra("clave", "escribir");
                startActivity(intent);
            }
        });

        adjuntar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity().getApplicationContext(), adjuntarRelato.class);
                startActivity(intent);
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void comprobarSonido(){
        if (md != null){
            md.stop();
            try {
                md.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        md.start();
    }
}