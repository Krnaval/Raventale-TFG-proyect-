package com.example.bvedadecuentos.ui;

import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class relato {

    private String titulo, autor, descripción, genero;
    private double puntuación;
    private Drawable portada;

    public relato(String titulo, String genero) {
        this.titulo = titulo;
        this.genero = genero;
    }

    public relato(String titulo, double puntuación) {
        this.titulo = titulo;
        this.puntuación = puntuación;
    }

    public relato(String titulo, String genero, String autor, String descripción) {
        this.titulo = titulo;
        this.genero = genero;
        this.autor = autor;
        this.descripción = descripción;
    }

    public relato(String titulo, Drawable portada) {
        this.titulo = titulo;
        this.portada = portada;
    }

    public relato(String titulo, String autor, String descripción, String genero, double puntuación, Drawable portada) {
        this.titulo = titulo;
        this.autor = autor;
        this.descripción = descripción;
        this.genero = genero;
        this.puntuación = puntuación;
        this.portada = portada;
    }

    public Drawable getPortada() {
        return portada;
    }

    public void setPortada(Drawable portada) {
        this.portada = portada;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getDescripción() {
        return descripción;
    }

    public void setDescripción(String descripción) {
        this.descripción = descripción;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public double getPuntuación() {
        return puntuación;
    }

    public void setPuntuación(double puntuación) {
        this.puntuación = puntuación;
    }
}
