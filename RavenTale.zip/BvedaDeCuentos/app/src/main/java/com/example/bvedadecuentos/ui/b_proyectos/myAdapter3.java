package com.example.bvedadecuentos.ui.b_proyectos;

import static android.app.Activity.RESULT_OK;


import static androidx.core.app.ActivityCompat.startActivityForResult;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.ui.relato;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class myAdapter3 extends RecyclerView.Adapter<myAdapter3.MyHolder>{

    private FirebaseFirestore db;
    private ArrayList<relato> listaRelatos = new ArrayList<>();
    private Activity mActivity;
    private Context contexto;


    public myAdapter3(ArrayList<relato>arr, Context context, Activity activity){
        //FUNCIONA
        listaRelatos = arr;
        contexto = context;
        mActivity = activity;


    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(contexto).inflate(R.layout.activity_caps_list, parent, false);
        return new MyHolder(view);

    }

    //REVISAR EL ONBINDVIEWHOLDER
    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.genero.setText(listaRelatos.get(position).getGenero());
        holder.titulo.setText(listaRelatos.get(position).getTitulo());
        holder.portada.setImageDrawable(listaRelatos.get(position).getPortada());

        holder.linearTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Crear menú emergente
                PopupMenu popup = new PopupMenu(holder.linearTotal.getContext(), holder.linearTotal);
                // Inflar menú desde archivo xml
                popup.getMenuInflater().inflate(R.menu.story_editor, popup.getMenu());
                // Asignar listener a las opciones del menú
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        System.out.println("ANTES DEL SWITCH");
                        switch (item.getItemId()) {
                            case R.id.editar:
                                // Acción para la opción 1
                                Intent intent = new Intent(contexto, crearRelato.class);
                                intent.putExtra("titulo", listaRelatos.get(position).getTitulo());
                                intent.putExtra("generos", listaRelatos.get(position).getGenero());
                                contexto.startActivity(intent);
                                //CAMBIAR A PENSTAÑA DE EDICION
                                break;
                            case R.id.publicar:
                                //VER ESTADO DEL RELATO
                                FirebaseFirestore db = FirebaseFirestore.getInstance();
                                System.out.println("PUBLIC");
                                String tituloBuscado = holder.titulo.getText().toString();
                                if (holder.genero.getText().toString().isEmpty()) {
                                    Toast.makeText(contexto, "El relato tiene que tener generos para publicarse", Toast.LENGTH_SHORT).show();
                                }else {
                                    String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

                                    DocumentReference autorRef = db.collection("autores").document(uid);
                                    db.collection("relatos")
                                            .whereEqualTo("titulo", tituloBuscado)
                                            .whereEqualTo("autor",autorRef)
                                            .get()
                                            .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                                @Override
                                                public void onSuccess(QuerySnapshot querySnapshot) {
                                                    if (!querySnapshot.isEmpty()) {
                                                        // El documento existe, obtener su contenido y verificar si es válido
                                                        String contenido = querySnapshot.getDocuments().get(0).getString("contenido");
                                                        if (contenido == null || contenido.trim().isEmpty()) {
                                                            // El contenido está vacío o es solo espacios en blanco
                                                            Toast.makeText(contexto, "El relato tiene que tener contenido para publicarse", Toast.LENGTH_SHORT).show();
                                                        } else {

                                                            db.collection("relatos")
                                                                    .whereEqualTo("titulo", tituloBuscado)
                                                                    .whereEqualTo("autor",autorRef)
                                                                    .get()
                                                                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                                                        @Override
                                                                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                                                            for (DocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                                                                                Boolean estado = documentSnapshot.getBoolean("estado");
                                                                                Log.d("Firestore", "El estado del libro es: " + estado);
                                                                                System.out.println("MIMI MIMI MIMIM IMIMI" + estado);
                                                                                if (estado == false) {
                                                                                    AlertDialog.Builder builder = new AlertDialog.Builder(contexto);
                                                                                    builder.setMessage("¿Está seguro de que desea publicar este relato?")
                                                                                            .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                                                                                                public void onClick(DialogInterface dialog, int id) {
                                                                                                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                                                                                                    CollectionReference relatosRef = db.collection("relatos");

// Buscar el relato por título
                                                                                                    System.out.println("COMPARE TO WOMAN'S KISS");
                                                                                                    String tituloBuscado = holder.titulo.getText().toString();
                                                                                                    System.out.println(tituloBuscado);


                                                                                                    Query query = relatosRef.whereEqualTo("titulo", tituloBuscado);

// Ejecutar la consulta
                                                                                                    query.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                                                                                        @Override
                                                                                                        public void onSuccess(QuerySnapshot querySnapshot) {
                                                                                                            // Si se encontró algún documento
                                                                                                            if (!querySnapshot.isEmpty()) {
                                                                                                                // Obtener el primer documento de la lista (suponiendo que no hay más de uno con el mismo título)
                                                                                                                DocumentSnapshot document = querySnapshot.getDocuments().get(0);

                                                                                                                // Actualizar el estado del relato
                                                                                                                document.getReference().update("estado", true).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                                                    @Override
                                                                                                                    public void onSuccess(Void aVoid) {

                                                                                                                    }
                                                                                                                }).addOnFailureListener(new OnFailureListener() {
                                                                                                                    @Override
                                                                                                                    public void onFailure(@NonNull Exception e) {
                                                                                                                        // Ocurrió un error al actualizar el estado
                                                                                                                    }
                                                                                                                });
                                                                                                            }
                                                                                                        }
                                                                                                    }).addOnFailureListener(new OnFailureListener() {
                                                                                                        @Override
                                                                                                        public void onFailure(@NonNull Exception e) {
                                                                                                            // Ocurrió un error al buscar el relato
                                                                                                        }
                                                                                                    });
                                                                                                    notifyDataSetChanged();

                                                                                                }

                                                                                                // Acción a realizar si se confirma la publicación del libro
                                                                                                //CAMBIARLO EN LA BASE DE DATOS


                                                                                            })
                                                                                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                                                                                public void onClick(DialogInterface dialog, int id) {
                                                                                                    // Acción a realizar si se cancela la publicación del libro
                                                                                                    dialog.cancel();
                                                                                                }
                                                                                            });
                                                                                    AlertDialog alertDialog = builder.create();
                                                                                    alertDialog.show();


                                                                                } else if (estado == true) {
                                                                                    AlertDialog.Builder builder = new AlertDialog.Builder(contexto);
                                                                                    builder.setMessage("¿Está seguro de que desea quitar la publicación de este relato?")
                                                                                            .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                                                                                                public void onClick(DialogInterface dialog, int id) {
                                                                                                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                                                                                                    CollectionReference relatosRef = db.collection("relatos");
// Buscar el relato por título
                                                                                                    String tituloBuscado = holder.titulo.getText().toString();
                                                                                                    System.out.println(tituloBuscado);


                                                                                                    Query query = relatosRef.whereEqualTo("titulo", tituloBuscado);

// Ejecutar la consulta
                                                                                                    query.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                                                                                        @Override
                                                                                                        public void onSuccess(QuerySnapshot querySnapshot) {
                                                                                                            // Si se encontró algún documento
                                                                                                            if (!querySnapshot.isEmpty()) {
                                                                                                                // Obtener el primer documento de la lista (suponiendo que no hay más de uno con el mismo título)
                                                                                                                DocumentSnapshot document = querySnapshot.getDocuments().get(0);

                                                                                                                // Actualizar el estado del relato
                                                                                                                document.getReference().update("estado", false).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                                                    @Override
                                                                                                                    public void onSuccess(Void aVoid) {
                                                                                                                        // El estado se actualizó correctamente
                                                                                                                    }
                                                                                                                }).addOnFailureListener(new OnFailureListener() {
                                                                                                                    @Override
                                                                                                                    public void onFailure(@NonNull Exception e) {
                                                                                                                        // Ocurrió un error al actualizar el estado
                                                                                                                    }
                                                                                                                });
                                                                                                            }
                                                                                                        }
                                                                                                    }).addOnFailureListener(new OnFailureListener() {
                                                                                                        @Override
                                                                                                        public void onFailure(@NonNull Exception e) {
                                                                                                            // Ocurrió un error al buscar el relato
                                                                                                        }
                                                                                                    });


                                                                                                    notifyDataSetChanged();
                                                                                                    // Acción a realizar si se confirma la publicación del libro
                                                                                                    //CAMBIARLO EN LA BASE DE DATOS


                                                                                                }
                                                                                            })
                                                                                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                                                                                public void onClick(DialogInterface dialog, int id) {
                                                                                                    // Acción a realizar si se cancela la publicación del libro
                                                                                                    dialog.cancel();
                                                                                                }
                                                                                            });
                                                                                    AlertDialog alertDialog = builder.create();
                                                                                    alertDialog.show();
                                                                                }
                                                                            }
                                                                        }
                                                                    });





                                                        }
                                                    } else {
                                                        // El documento no existe
                                                        Toast.makeText(contexto, "El relato no existe", Toast.LENGTH_SHORT).show();
                                                    }
                                                }
                                            });





                                }

                                // Acción para la opción 2


                                break;
                            case R.id.borrar:
                                // Acción para la opción 3
                                AlertDialog.Builder builder2 = new AlertDialog.Builder(contexto);
                                builder2.setMessage("¿Está seguro de que desea borrar este libro?")
                                        .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                // Acción a realizar si se confirma la publicación del libro
                                                FirebaseFirestore db = FirebaseFirestore.getInstance();
                                                CollectionReference relatosRef = db.collection("relatos");
                                                //CAMBIARLO EN LA BASE DE DATOS
                                                String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

                                                DocumentReference autorRef = db.collection("autores").document(uid);
                                                String valorAEliminar =  holder.titulo.getText().toString();
                                                Query query = relatosRef.whereEqualTo("titulo", valorAEliminar)
                                                        .whereEqualTo("autor",autorRef)
                                                        ;

// Ejecutar la consulta
                                                query.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                                            @Override
                                                            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                                                for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                                                                    documentSnapshot.getReference().delete();
                                                                    listaRelatos.remove(position);
                                                                    notifyItemRemoved(position);
                                                                }
                                                            }
                                                        })
                                                        .addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@org.checkerframework.checker.nullness.qual.NonNull Exception e) {
                                                            }
                                                        });


                                                //ACTUALIZAR RECYCLER
                                                notifyItemChanged(position);
                                            }
                                        })
                                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                // Acción a realizar si se cancela la publicación del libro
                                                dialog.cancel();
                                            }
                                        });
                                AlertDialog alertDialog1 = builder2.create();
                                alertDialog1.show();
                                break;
                        }
                        return true;
                    }
                });

                // Mostrar menú emergente
                popup.show();
            }
        });








    }

    private AdapterCallback mAdapterCallback;

    public void setAdapterCallback(AdapterCallback callback) {
        mAdapterCallback = callback;
    }


    public interface AdapterCallback {
        void onMenuItemClicked(String relatoId, String tituloBuscado, DocumentReference autorRef);
    }






    @Override
    public int getItemCount() {
        return listaRelatos.size();
    }

    class MyHolder extends RecyclerView.ViewHolder{
        TextView titulo;
        TextView genero;
        ImageView portada;
        LinearLayout linearTotal;

        public MyHolder (@NonNull View itemView){
            super(itemView);
            titulo = itemView.findViewById(R.id.textView16);
            genero = itemView.findViewById(R.id.textView17);
            portada = itemView.findViewById(R.id.imageView5);
            linearTotal = itemView.findViewById(R.id.linearTotal);
        }
    }


}
