package com.example.bvedadecuentos.ui.a_inicio;

import static android.content.ContentValues.TAG;

import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.ui.relato;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;


public class FirstFragment extends Fragment {
    private listaRelatosAdapter adapter;
    private LinearLayoutManager linearLayoutManager;
    String messages = "";
    DocumentReference autorRef;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recycler1);

        Bundle args = getArguments();
        if (args != null) {
            String message = args.getString("message");
            // Hacer algo con el mensaje
            messages = message;
        }

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("autores")
                .whereGreaterThanOrEqualTo("Name", messages)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot querySnapshot, @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            Log.w(TAG, "Listen failed.", e);
                            return;
                        }

                        if (querySnapshot != null && !querySnapshot.isEmpty()) {
                            // Si se encontró el documento del autor, obtener su referencia
                            DocumentSnapshot document = querySnapshot.getDocuments().get(0);
                            autorRef = document.getReference();
                            System.out.println(autorRef.getPath());

                            recyclerView.setHasFixedSize(true);
                            // Cargar recyclerView con datos
                            linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
                            recyclerView.setLayoutManager(linearLayoutManager);
                            recyclerView.setAdapter(adapter);

                            ArrayList<relato> relatos = new ArrayList<>();
                            CollectionReference relatosRef = db.collection("relatos");
                            FirebaseAuth auth = FirebaseAuth.getInstance();
                            FirebaseUser currentUser = auth.getCurrentUser();

                            if (currentUser != null) {
                                Query query = relatosRef.whereEqualTo("autor", autorRef).whereEqualTo("estado", true);

                                query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                        if (task.isSuccessful()) {
                                            // la consulta se ejecutó correctamente, recorre los documentos resultantes
                                            Drawable drawable = getResources().getDrawable(R.drawable.imagess);
                                            System.out.println("ESTOY AQUI 1");
                                            if (task.getResult().isEmpty()) {
                                                System.out.println("Hay " + task.getResult().size() + " documentos que cumplen con el filtro.");
                                            }
                                            for (DocumentSnapshot document : task.getResult().getDocuments()) {
                                                System.out.println("ESTOY AQUI 2");
                                                // obtén los campos del documento y haz lo que necesites con ellos
                                                String titulo = document.getString("titulo");
                                                DocumentReference autorRef = document.getDocumentReference("autor");
                                                String descripcion = document.getString("contenido");
                                                String genero = document.getString("genero");
                                                double puntuacion = document.getDouble("puntuacion");
                                                System.out.println(titulo + "," + genero);

                                                // crea un objeto "relato" con los campos del documento y agrega a la lista de relatos del autor
                                                relato relato = new relato(titulo, autorRef.getPath(), descripcion, genero, puntuacion, drawable);
                                                relatos.add(relato);
                                                System.out.println(relatos.size());
                                                System.out.println(relatos.get(0).getAutor());
                                                adapter = new listaRelatosAdapter(relatos, getContext());
                                                recyclerView.setAdapter(adapter);

                                            }

                                            // haz lo que necesites con la lista de relatos del autor
                                        } else {
                                            Log.d(TAG, "Error getting documents: ", task.getException());
                                        }
                                    }
                                });
                            }
                        }
                    }
                });




        return view;

    }
}