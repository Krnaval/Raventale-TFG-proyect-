package com.example.bvedadecuentos.ui.b_proyectos;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.TextView;

import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.ui.relato;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;

public class listarRelatos extends AppCompatActivity  {

    private RecyclerView recyclerModelo;
    private TextView nombre, descr;
    private LinearLayoutManager linearLayoutManager;
    private myAdapter3 adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caps);

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        recyclerModelo = findViewById(R.id.recyclerviewcaps);
        recyclerModelo.setHasFixedSize(true);
        // Cargar recyclerView Con datos
        linearLayoutManager = new LinearLayoutManager(listarRelatos.this, LinearLayoutManager.VERTICAL, false);
        recyclerModelo.setLayoutManager(linearLayoutManager);
        ArrayList<relato> relatos = new ArrayList<>();

        // CARGAR RECYCLER CON DATOS DE LA BASE DE DATOS
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference relatosRef = db.collection("relatos");
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = auth.getCurrentUser();
        if (currentUser != null) {
            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DocumentReference autorRef = db.collection("autores").document(uid);
            Query query = relatosRef.whereEqualTo("autor", autorRef);

            query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful()) {
                        // La consulta se ejecutó correctamente, recorre los documentos resultantes
                        Drawable drawable = getResources().getDrawable(R.drawable.imagess);
                        System.out.println("ESTOY AQUI 1");
                        if (task.getResult().isEmpty()) {
                            System.out.println("Hay " + task.getResult().size() + " documentos que cumplen con el filtro.");
                            System.out.println(autorRef);
                        }
                        for (DocumentSnapshot document : task.getResult().getDocuments()) {
                            System.out.println("ESTOY AQUI 2");
                            // Obtén los campos del documento y haz lo que necesites con ellos
                            String titulo = document.getString("titulo");
                            DocumentReference autorRef = document.getDocumentReference("autor");
                            String descripcion = document.getString("contenido");
                            String genero = document.getString("genero");
                            double puntuacion = document.getDouble("puntuacion");
                            System.out.println(titulo + "," + genero);

                            // Crea un objeto "relato" con los campos del documento y agrega a la lista de relatos del autor
                            relato relato = new relato(titulo, autorRef.getPath(), descripcion, genero, puntuacion, drawable);
                            relatos.add(relato);
                            System.out.println(relatos.size());
                            System.out.println(relatos.get(0).getAutor());
                            adapter = new myAdapter3(relatos, listarRelatos.this, listarRelatos.this);
                            recyclerModelo.setAdapter(adapter);
                        }

                        // Haz lo que necesites con la lista de relatos del autor
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());
                    }
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }



}