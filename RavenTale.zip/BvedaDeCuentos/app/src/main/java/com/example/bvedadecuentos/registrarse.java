package com.example.bvedadecuentos;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MotionEventCompat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class registrarse extends AppCompatActivity {
    private static final String DEBUG_TAG = "A";

    private TextView volverAlLogin;
    private Button registrarse;
    private FirebaseFirestore firebase = FirebaseFirestore.getInstance();
    private FirebaseAuth aut;
    private EditText nombre, contrasenya, ccontrasenya, gmail;
    public static final String LOGIN = "login";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarse);
        registrarse = findViewById(R.id.button);
        nombre = findViewById(R.id.editTextTextPersonName4);
        gmail = findViewById(R.id.editTextTextPersonName);
        contrasenya = findViewById(R.id.editTextTextPersonName2);
        ccontrasenya = findViewById(R.id.editTextTextPersonName3);
        SharedPreferences login = getSharedPreferences(LOGIN, Context.MODE_PRIVATE);
        getSupportActionBar().hide();

        volverAlLogin = findViewById(R.id.textView9);


        volverAlLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Cambio = new Intent(getApplicationContext(), login.class);
                startActivity(Cambio);
            }
        });

        registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((nombre.getText().toString().equalsIgnoreCase(""))) {
                    nombre.setError("Este campo es obligatorio");
                    nombre.requestFocus();
                    return;

                } else if ((gmail.getText().toString().equalsIgnoreCase(""))) {
                    gmail.setError("Este campo es obligatorio");
                    gmail.requestFocus();
                    return;
                } else if ((contrasenya.getText().toString().equalsIgnoreCase(""))) {
                    contrasenya.setError("Este campo es obligatorio");
                    contrasenya.requestFocus();
                    return;
                } else if (ccontrasenya.getText().toString().equalsIgnoreCase("")) {
                    ccontrasenya.setError("Este campo es obligatorio");
                    ccontrasenya.requestFocus();
                    return;
                } else {
                    contrasenya.setError(null);
                    ccontrasenya.setError(null);
                    nombre.setError(null);
                    gmail.setError(null);
                }


                if (isComprobarLongitudError()) {
                    return;
                }
                if (isComprobarContrasenyasIguales()) {
                    return;
                }

                registrarEnBaseDeDatos();
                guardarEnShareLogin();
                volverAlLogin.performClick();
            }


            private boolean isComprobarLongitudError() {
                if (ccontrasenya.getText().length() < 6) {
                    ccontrasenya.setError("Este campo tiene que ser mayor a 6 caracteres");
                    ccontrasenya.requestFocus();

                    return true;
                } else if (contrasenya.getText().length() < 6) {
                    contrasenya.setError("Este campo tiene que ser mayor a 6 caracteres");
                    contrasenya.requestFocus();

                    return true;
                } else if (ccontrasenya.getText().length() > 12) {
                    ccontrasenya.setError("Este campo tiene que ser menor a 12 caracteres");
                    ccontrasenya.requestFocus();

                    return true;
                } else if (contrasenya.getText().length() > 12) {
                    contrasenya.setError("Este campo tiene que ser menor a 12 caracteres");
                    contrasenya.requestFocus();

                    return true;
                }
                return false;
            }


            private boolean isComprobarContrasenyasIguales() {

                System.out.println(ccontrasenya.getText().toString());


                System.out.println(contrasenya.getText().toString());
                if (!ccontrasenya.getText().toString().equals(contrasenya.getText().toString())) {
                    ccontrasenya.setError("Este campo tiene que ser igual al anterior");
                    ccontrasenya.requestFocus();
                    contrasenya.setError("Este campo tiene que ser igual al siguiente");
                    contrasenya.requestFocus();
                    return true;
                }
                return false;

            }

            private void guardarEnShareLogin() {
                login.edit().putString("Gmail", gmail.getText().toString()).apply();
                login.edit().putString("Password", contrasenya.getText().toString()).apply();
                login.edit().putString("Name", nombre.getText().toString()).apply();


            }




            //Registrar usuario en la base de datos
            private void registrarEnBaseDeDatos() {
                //Creamos una instancia del servicio de autentificación
                aut = FirebaseAuth.getInstance();
                //Pasamos los parametros al servicio
                aut.createUserWithEmailAndPassword(gmail.getText().toString(), contrasenya.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        //Creamos un map con los valores que queremos almacenar en la base de datos
                        Map<String, Object> map = new HashMap<>();
                        String id = aut.getCurrentUser().getUid();
                        map.put("id", id);
                        map.put("Name", nombre.getText().toString());
                        map.put("Password", contrasenya.getText().toString());
                        map.put("Gmail", gmail.getText().toString());

                        //Hacemos una consulta a la base de datos
                        firebase.collection("autores").document(id).set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                //En caso de que sea un exito





                                Toast.makeText(getApplicationContext(), "Guardado con exito", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                //En caso de que falle el registro
                                Toast.makeText(getApplicationContext(), "Error a la hora de registrarse en la base de datos", Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                });
            }
        });
    }

}