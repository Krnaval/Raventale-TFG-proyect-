package com.example.bvedadecuentos.ui.a_inicio;

import static android.content.ContentValues.TAG;

import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.ui.relato;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;


public class ThreeFragment extends Fragment {
    private listaRelatosAdapter adapter;
    private LinearLayoutManager linearLayoutManager;
    String messages;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_first, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recycler1);

        Bundle args = getArguments();
        if (args == null) {


        }else if (args.equals("")){

        }else{
            String message = args.getString("message");
            // Hacer algo con el mensaje
            messages = message;
            System.out.println(messages);
        }





        recyclerView.setHasFixedSize(true);
        //Cargar recyclerView Con datos
        linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);


        ArrayList<relato> relatos = new ArrayList<>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference relatosRef = db.collection("relatos");
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = auth.getCurrentUser();

        if (currentUser != null) {
            Query query1 = relatosRef.whereGreaterThanOrEqualTo("genero_1", messages).whereEqualTo("estado", true);
            Query query2 = relatosRef.whereGreaterThanOrEqualTo("genero_2", messages).whereEqualTo("estado", true);
            Query query3 = relatosRef.whereGreaterThanOrEqualTo("genero_3", messages).whereEqualTo("estado", true);

            Task<QuerySnapshot> query1Task = query1.get();
            Task<QuerySnapshot> query2Task = query2.get();
            Task<QuerySnapshot> query3Task = query3.get();

            Tasks.whenAllComplete(query1Task, query2Task, query3Task).addOnCompleteListener(new OnCompleteListener<List<Task<?>>>() {
                @Override
                public void onComplete(@NonNull Task<List<Task<?>>> task) {
                    for (Task<?> q : task.getResult()) {
                        if (!q.isSuccessful()) {
                            Log.w(TAG, "Error getting documents.", q.getException());
                            return;
                        }
                        QuerySnapshot querySnapshot = (QuerySnapshot) q.getResult();
                        for (DocumentSnapshot document : querySnapshot.getDocuments()) {
                            // obtén los campos del documento y haz lo que necesites con ellos
                            String titulo = document.getString("titulo");
                            DocumentReference autorRef = document.getDocumentReference("autor");
                            String descripcion = document.getString("contenido");
                            String genero = document.getString("genero");
                            double puntuacion = document.getDouble("puntuacion");
                            Drawable drawable = getResources().getDrawable(R.drawable.imagess);

                            // crea un objeto "relato" con los campos del documento y agrega a la lista de relatos del autor
                            relato relato = new relato(titulo, autorRef.getPath(), descripcion, genero, puntuacion, drawable);
                            relatos.add(relato);
                        }
                    }

                    // crea un adaptador y configura el RecyclerView
                    adapter = new listaRelatosAdapter(relatos, getContext());
                    recyclerView.setAdapter(adapter);
                }
            });
        }

        return view;
    }
}