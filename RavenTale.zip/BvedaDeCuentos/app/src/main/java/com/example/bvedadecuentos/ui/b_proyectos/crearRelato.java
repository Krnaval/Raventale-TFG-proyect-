package com.example.bvedadecuentos.ui.b_proyectos;

import static android.content.ContentValues.TAG;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.bvedadecuentos.MainActivity;
import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.ui.relato;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class crearRelato extends AppCompatActivity {

    private ImageButton returnBack, saveAndContinue;
    static EditText titulo, contenido;
    String generosRelato;
    String nombreRelato;
    String genero_1, genero_2, genero_3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_relato);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();



        saveAndContinue = findViewById(R.id.imageButton2);
        titulo = findViewById(R.id.editTextTextPersonName6);
        contenido = findViewById(R.id.editTextTextMultiLine);

        titulo.setText("");
        contenido.setText("");
        nombreRelato = null;
        generosRelato = null;

        titulo.setFocusable(true);
        titulo.setFocusableInTouchMode(true);
        titulo.setClickable(true);

        // Obtiene el nombre del libro enviado desde otro activity mediante el intent
        Intent intent = getIntent();
        nombreRelato = intent.getStringExtra("titulo");
        generosRelato = intent.getStringExtra("generos");
        if (nombreRelato != null){
            titulo.setFocusable(false);
            titulo.setFocusableInTouchMode(false);
            titulo.setClickable(false);
        }

        // Si se recibió un nombre de libro, busca sus datos en la base de datos
        if (nombreRelato != null) {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("relatos").whereEqualTo("titulo", nombreRelato).get()
                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                        @Override
                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                            if (!queryDocumentSnapshots.isEmpty()) {
                                // Si encontró el libro en la base de datos, actualiza los EditText con sus datos
                                String tituloLibro = queryDocumentSnapshots.getDocuments().get(0).getString("titulo");
                                String contenidoLibro = queryDocumentSnapshots.getDocuments().get(0).getString("contenido");
                                titulo.setText(tituloLibro);
                                contenido.setText(contenidoLibro);
                            }
                        }
                    });
        }

      saveAndContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nombreRelato == null){
                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                    DocumentReference autorRef = db.collection("autores").document(uid);
                    String titulos = titulo.getText().toString().trim();
                    if (titulos.isEmpty() || !titulos.matches("^[a-zA-Z0-9 ]+$")) {
                        Toast.makeText(getApplicationContext(), "Por favor, ingrese un nombre de relato válido.", Toast.LENGTH_SHORT).show();
                    } else {
                        db = FirebaseFirestore.getInstance();
                        db.collection("relatos").
                                whereEqualTo("titulo", titulos)
                                .whereEqualTo("autor",autorRef)
                                .get()
                                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                    @Override
                                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                        if (queryDocumentSnapshots.isEmpty()) {
                                            System.out.println("MI MI ESTA AGA");
                                            generos();
                                        } else {
                                            Toast.makeText(getApplicationContext(), "El libro ya existe en la base de datos. No se puede guardar.", Toast.LENGTH_SHORT).show();
                                        }
                                    }


                                });
                    }
                }else{
                    generos();
                }



            }
        });



    }





    private void generos() {
        final String[] genres = {"Novela", "Poesía", "Drama", "Ciencia Ficción", "Misterio", "Romance", "Fantasía", "Aventura", "Historia", "Infantil", "Juvenil", "Terror", "Cosas de la vida"};
        boolean[] checkedItems = new boolean[genres.length];
// Seleccionar los géneros que existen en generosRelato
        if (generosRelato != null){
            String[] generosArray = generosRelato.split(", ");
            for (int i = 0; i < genres.length; i++) {
                if (Arrays.asList(generosArray).contains(genres[i])) {
                    checkedItems[i] = true;
                }
            }
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecciona géneros (máximo 3)");
        builder.setMultiChoiceItems(genres, checkedItems, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                // No se necesita implementar nada aquí
            }
        });

        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ArrayList<String> selectedGenres = new ArrayList<String>();
                int count = 0;
                for (int i = 0; i < checkedItems.length; i++) {
                    if (checkedItems[i]) {
                        count++;
                        selectedGenres.add(genres[i]);
                    }
                }

                if (count > 3) {
                    Toast.makeText(getApplicationContext(), "Solo se permiten hasta 3 géneros", Toast.LENGTH_SHORT).show();
                } else {
                    String genresText = "";
                    int contador = 1;
                    for (String genre : selectedGenres) {
                        genresText += genre + ", ";
                        if (contador == 1){
                            genero_1 = genre;
                        }
                        if (contador == 2){
                            genero_2 = genre;
                        }
                        if (contador == 3){
                            genero_3 = genre;
                        }
                        contador++;
                    }
                    boolean enviar = true;

                    if (!genresText.isEmpty()) {
                        genresText = genresText.substring(0, genresText.length() - 2);
                        Toast.makeText(getApplicationContext(), "Géneros seleccionados: " + genresText, Toast.LENGTH_SHORT).show();
                    }
                    if (enviar) {
                        try {
                            guardarNormal(genresText);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }


        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }


    private void guardarNormal(String genresText) throws IOException {
        String titulos = titulo.getText().toString();
        String contenidos = contenido.getText().toString();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference relatosRef = db.collection("relatos");

        if (nombreRelato != null) {
            db.collection("relatos").whereEqualTo("titulo", titulos).get()
                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                        @Override
                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                            if (!queryDocumentSnapshots.isEmpty()) {
                                String idDelDocumento = queryDocumentSnapshots.getDocuments().get(0).getId();

                                // Crear el mapa con los campos a actualizar
                                Map<String, Object> datosAActualizar = new HashMap<>();
                                datosAActualizar.put("genero", genresText);
                                datosAActualizar.put("contenido", contenidos);
                                datosAActualizar.put("genero_1", genero_1);
                                datosAActualizar.put("genero_2", genero_2);
                                datosAActualizar.put("genero_3", genero_3);
                                generosRelato = genresText;

                                // Actualizar el documento
                                relatosRef.document(idDelDocumento).update(datosAActualizar)
                                        .addOnSuccessListener(documentReference -> {
                                            Log.d(TAG, "Relato actualizado con ID: " + idDelDocumento);
                                        })
                                        .addOnFailureListener(e -> {
                                            Log.w(TAG, "Error actualizando el relato", e);
                                        });
                            } else {
                                Toast.makeText(getApplicationContext(), "El libro no existe en la base de datos. No se puede actualizar.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }else{

            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

            DocumentReference autorRef = db.collection("autores").document(uid);
            db.collection("relatos").whereEqualTo("titulo", titulos)
                    .whereEqualTo("autor",autorRef)
                    .get()
                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                        @Override
                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                            if (queryDocumentSnapshots.isEmpty()) {
                                System.out.println("MI MI ESTA AGA");
                                if (titulos.isEmpty()) {
                                    Toast.makeText(crearRelato.this, "No tiene titulo", Toast.LENGTH_LONG).show();
                                    return;
                                }

                                FirebaseFirestore fr = FirebaseFirestore.getInstance();
                                CollectionReference relatosRef = fr.collection("relatos");
                                FirebaseAuth auth = FirebaseAuth.getInstance();
                                FirebaseUser currentUser = auth.getCurrentUser();

                                if (currentUser != null) {
                                    String autor = currentUser.getUid();
                                    String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                    DocumentReference autorRef = db.collection("autores").document(uid);
                                    relato relato = new relato(titulos, genresText, autorRef.getPath(), contenidos);

                                    Map<String, Object> relatoMap = new HashMap<>();
                                    relatoMap.put("titulo", relato.getTitulo().toUpperCase());
                                    relatoMap.put("contenido", relato.getDescripción());
                                    relatoMap.put("autor", autorRef);
                                    relatoMap.put("estado", false);
                                    relatoMap.put("genero", relato.getGenero());
                                    relatoMap.put("puntuacion", 0);
                                    relatoMap.put("genero_1", genero_1);
                                    relatoMap.put("genero_2", genero_2);
                                    relatoMap.put("genero_3", genero_3);
                                    generosRelato = relato.getGenero();
                                    relatosRef.add(relatoMap).addOnSuccessListener(documentReference -> {
                                                Log.d(TAG, "Relato añadido con ID: " + documentReference.getId());

                                            })
                                            .addOnFailureListener(e -> {
                                                Log.w(TAG, "Error añadiendo el relato", e);
                                            });

                                    DocumentReference autorReff = db.collection("autores").document(uid);

                                    relatosRef.whereEqualTo("titulo", relato.getTitulo().toUpperCase())
                                            .whereEqualTo("autor", autorReff).
                                            get().addOnSuccessListener(querySnapshot -> {
                                                for (DocumentSnapshot documentSnapshot : querySnapshot.getDocuments()) {
                                                    String  relatoId = documentSnapshot.getId();
                                                    System.out.println("MUESTRA DE RELATO ID "+relatoId);
                                                    System.out.println("MUESTRA DE UATORREFF "+autorReff.getPath());

                                                    System.out.println("*************************");
                                                    System.out.println(autorReff.getPath()+"||"+relato.getTitulo().toUpperCase()+"||"+relatoId);
                                                    System.out.println("*************************");
                                                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                                    intent.putExtra("relatoId", relatoId);
                                                    intent.putExtra("autorRef", autorReff.getPath());

                                                    startActivityForResult(intent, 2);                                                                                                                            }
                                            }).addOnFailureListener(e -> {
                                                // Manejar la falla de la consulta...
                                            }).addOnSuccessListener(e -> {

                                            });






                                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                                    relatosRef = db.collection("relatos");

// Realizar una consulta para obtener los relatos



                                } else {
                                    // No hay usuario autenticado, hacer algo en consecuencia
                                }

                            } else {
                                Toast.makeText(getApplicationContext(), "El libro ya existe en la base de datos. No se puede guardar.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });


        }
    }



    @Override
    public void onBackPressed() {

        AlertDialog.Builder builder = new AlertDialog.Builder(crearRelato.this);
        builder.setTitle("Importante");
        builder.setMessage("El contenido del relato se perderá si no se ha guardado en la base de datos. ¿Estás seguro que deseas salir?");
        builder.setPositiveButton("Salir", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                finish();
            }
        }).setNegativeButton("Volver", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

            }
        });
        builder.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == 2) {
            Uri selectedImageUri = data.getData();  // Obtener la Uri de la imagen seleccionada
            String relatoId = data.getStringExtra("relatoId");  // Obtener el identificador del relato
            String tituloBuscado = data.getStringExtra("tituloBuscado");  // Obtener el título buscado
            ProgressDialog progressDialog = new ProgressDialog(crearRelato.this);
            progressDialog.setMessage("Subiendo relato...");
            System.out.println(relatoId + "    " + tituloBuscado);
            progressDialog.setCancelable(false);
            progressDialog.show();
            System.out.println("" + tituloBuscado + "||" + relatoId);

            // Haz lo que necesites con la imagen y el campo adicional

            getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

            FirebaseStorage storage = FirebaseStorage.getInstance();
            StorageReference storageRef = storage.getReference();
            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            String storagePath = "relatos/" + uid + "/portada.jpg";
            System.out.println("autores/"+uid+"/"+"/portada.jpg");

            StorageReference imageRef = storageRef.child(storagePath);
            imageRef.putFile(selectedImageUri)
                    .addOnSuccessListener(taskSnapshot -> {
                        // Obtener la URL de descarga de la imagen
                        imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                            // Guardar la URL en la base de datos de Firebase Firestore
                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                            DocumentReference relatoRef = db.collection("autores").document(uid);
                            relatoRef.get().addOnCompleteListener(task -> {
                                if (task.isSuccessful() && task.getResult() != null) {
                                    DocumentSnapshot document = task.getResult();
                                    if (document.exists()) {
                                        relatoRef.update("profileImageUrl", uri.toString())
                                                .addOnSuccessListener(aVoid -> {
                                                    progressDialog.dismiss();
                                                    Toast.makeText(crearRelato.this, "Imagen subida correctamente", Toast.LENGTH_SHORT).show();
                                                    // Habilitar interacción del usuario con la pantalla
                                                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                                                })
                                                .addOnFailureListener(e -> {
                                                    progressDialog.dismiss();
                                                    Toast.makeText(crearRelato.this, "Error al guardar la URL de la imagen", Toast.LENGTH_SHORT).show();
                                                    // Habilitar interacción del usuario con la pantalla
                                                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                                                });
                                    } else {
                                        progressDialog.dismiss();
                                        Toast.makeText(crearRelato.this, "No existe el relato en la base de datos", Toast.LENGTH_SHORT).show();
                                        // Habilitar interacción del usuario con la pantalla
                                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                                    }
                                } else {
                                    progressDialog.dismiss();
                                    Toast.makeText(crearRelato.this, "Error al obtener el relato de la base de datos", Toast.LENGTH_SHORT).show();
                                    // Habilitar interacción del usuario con la pantalla
                                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                                }
                            });
                        });
                    })
                    .addOnFailureListener(e -> Toast.makeText(crearRelato.this, "Error al subir la imagen", Toast.LENGTH_SHORT).show());
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            finish();
        }
        else {

        }
    }




}


