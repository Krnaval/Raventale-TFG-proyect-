package com.example.bvedadecuentos.ui.b_proyectos;

import static android.content.ContentValues.TAG;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.FileUtils;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.ui.relato;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;


import org.checkerframework.checker.nullness.qual.NonNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class adjuntarRelato extends AppCompatActivity {
    private static final int REQUEST_CODE_PICK_FILE = 10;
    private static final int REQUEST_CODE_READ_EXTERNAL_STORAGE = 100;
    private static final int REQUEST_CODE_WRITE_EXTERNAL_STORAGE = 1000;
    private static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 10000;
    private String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
    String genero_1, genero_2, genero_3;

    Button selectFileButton, savePDF, saveNeutral;
    TextView textView;
    boolean enviar = false;
    String generos ="";
    Uri direccion;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adjuntar_relato);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        selectFileButton = findViewById(R.id.select_file_button);
        textView = findViewById(R.id.contenido_text_view);
        PDFBoxResourceLoader.init(getApplicationContext());

        ImageButton myButton = findViewById(R.id.imageButton4);
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopup();
            }
        });

        saveNeutral = findViewById(R.id.button6);
        saveNeutral.setVisibility(View.INVISIBLE);

        saveNeutral.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(adjuntarRelato.this);
                builder.setTitle("Ingrese el nombre del relato:");

                final EditText input = new EditText(getApplicationContext());
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                builder.setView(input);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {




                        String titulo = input.getText().toString().trim();
                        if (titulo.isEmpty() || !titulo.matches("^[a-zA-Z0-9 ]+$")) {
                            Toast.makeText(getApplicationContext(), "Por favor, ingrese un nombre de relato válido.", Toast.LENGTH_SHORT).show();
                        } else {
                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                            DocumentReference autorRef = db.collection("autores").document(uid);
                            db.collection("relatos").whereEqualTo("titulo", titulo.toUpperCase())
                                    .whereEqualTo("autor",autorRef)
                                    .get()
                                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                        @Override
                                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                            if (queryDocumentSnapshots.isEmpty()) {
                                                System.out.println("MI MI ESTA AGA");
                                                generos(titulo, 1);
                                            } else {
                                                Toast.makeText(getApplicationContext(), "El libro ya existe en la base de datos. No se puede guardar.", Toast.LENGTH_SHORT).show();
                                            }
                                        }


                                    });
                        }
                    }
                });

                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();


            }
        });

        savePDF = findViewById(R.id.button5);
        savePDF.setVisibility(View.INVISIBLE);

        savePDF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(adjuntarRelato.this);
                builder.setTitle("Ingrese el nombre del relato:");

                final EditText input = new EditText(getApplicationContext());
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                builder.setView(input);

                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String titulo = input.getText().toString().trim();
                        if (titulo.isEmpty() || !titulo.matches("^[a-zA-Z0-9 ]+$")) {
                            Toast.makeText(getApplicationContext(), "Por favor, ingrese un nombre de relato válido.", Toast.LENGTH_SHORT).show();
                        } else {

                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                            DocumentReference autorRef = db.collection("autores").document(uid);

                            db.collection("relatos").whereEqualTo("titulo", titulo.toUpperCase())
                                    .whereEqualTo("autor",autorRef)
                                    .get()
                                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                        @Override
                                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                            if (queryDocumentSnapshots.isEmpty()) {
                                                System.out.println("MI MI ESTA AGA");
                                                generos(titulo, 2);
                                            } else {
                                                Toast.makeText(getApplicationContext(), "El libro ya existe en la base de datos. No se puede guardar.", Toast.LENGTH_SHORT).show();
                                            }
                                        }


                                    });
                        }
                    }
                });

                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();


            }
        });

        selectFileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*"); // Permite seleccionar cualquier tipo de archivo
                startActivityForResult(intent, REQUEST_CODE_PICK_FILE);
            }
        });
    }

    private void guardarPDF(String generos, String titulo) throws FileNotFoundException {
        if (direccion == null) {
            Toast.makeText(getApplicationContext(), "Por favor, seleccione un archivo PDF.", Toast.LENGTH_SHORT).show();
            return;
        }
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        DocumentReference autorRef = db.collection("autores").document(uid);

        System.out.println(direccion.getPath().toString());
        StorageReference storageRef = FirebaseStorage.getInstance().getReference();
        StorageReference pdfRef = storageRef.child("relatos/"+ autorRef+"/"+ generos + ".pdf");
        direccion = Uri.parse(direccion.toString());

        try {
            guardarNormal(generos, titulo);
        } catch (IOException e) {
            e.printStackTrace();
        }


        pdfRef.putFile(direccion)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Toast.makeText(getApplicationContext(), "Archivo PDF guardado correctamente en Firebase.", Toast.LENGTH_SHORT).show();

                        // Agrega el documento a la colección del usuario en Firestore
                        FirebaseFirestore db = FirebaseFirestore.getInstance();
                        FirebaseAuth mAuth = FirebaseAuth.getInstance();
                        String usuarioId = mAuth.getCurrentUser().getUid();
                        db.collection("autores").document(usuarioId).collection("relatos").add(new relato(titulo, generos))
                                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                    @Override
                                    public void onSuccess(DocumentReference documentReference) {
                                        Toast.makeText(getApplicationContext(), "Documento guardado correctamente en Firestore.", Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(getApplicationContext(), "Error al guardar el documento en Firestore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), "Error al guardar el archivo PDF en Firebase: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }





        @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_PICK_FILE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            direccion = uri;
            System.out.println(direccion.getPath());
            System.out.println(uri.getPath());

            String contenido = leerContenidoPDF(uri);
            textView.setText(contenido);
            if (!contenido.isEmpty()) {
                saveNeutral.setVisibility(View.VISIBLE);
                savePDF.setVisibility(View.VISIBLE);
            }

        }
    }



    private String leerContenidoPDF(Uri uri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            PDDocument document = PDDocument.load(inputStream);
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String texto = pdfStripper.getText(document);
            document.close();
            return texto;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void showPopup() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Importante");
        builder.setMessage("El contenido del pdf tiene que ser el contenido que se desea dentro del relato, posteriormente se añadirá el titulo y los generos. No se garantiza que el formato estandar guarde toda la infomación correctamente o en el formato deseado, pero será accesible a todo el público.");
        builder.setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // Acción a realizar al hacer clic en el botón de Más información
            }
        });
        builder.show();
    }


    private void generos(String titulo, int num) {
        final String[] genres = {"Novela", "Poesía", "Drama", "Ciencia Ficción", "Misterio", "Romance", "Fantasía", "Aventura", "Historia", "Infantil", "Juvenil", "Terror", "Cosas de la vida"};
        boolean[] checkedItems = new boolean[genres.length];
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecciona géneros (máximo 3)");
        builder.setMultiChoiceItems(genres, checkedItems, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                // No se necesita implementar nada aquí
            }
        });

        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ArrayList<String> selectedGenres = new ArrayList<String>();
                int count = 0;
                for (int i = 0; i < checkedItems.length; i++) {
                    if (checkedItems[i]) {
                        count++;
                        selectedGenres.add(genres[i]);
                    }
                }

                if (count > 3) {
                    Toast.makeText(getApplicationContext(), "Solo se permiten hasta 3 géneros", Toast.LENGTH_SHORT).show();
                } else {
                    String genresText = "";
                    int contador = 1;
                    for (String genre : selectedGenres) {
                        genresText += genre + ", ";
                        if (contador == 1) {
                            genero_1 = genre;
                        }
                        if (contador == 2) {
                            genero_2 = genre;
                        }
                        if (contador == 3) {
                            genero_3 = genre;
                        }
                        contador++;
                    }
                    enviar = true;

                    if (!genresText.isEmpty()) {
                        genresText = genresText.substring(0, genresText.length() - 2);
                        Toast.makeText(getApplicationContext(), "Géneros seleccionados: " + genresText, Toast.LENGTH_SHORT).show();
                    }
                    if (num == 2){
                        try {
                            guardarPDF(titulo, genresText);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }

                    }else if (num == 1){
                        try {
                            guardarNormal(titulo, genresText);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }


        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }
    private void guardarNormal(String titulo, String genresText) throws IOException {
        String contenido = textView.getText().toString();
        FirebaseFirestore fr = FirebaseFirestore.getInstance();
        CollectionReference relatosRef = fr.collection("relatos");
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = auth.getCurrentUser();

        if (currentUser != null) {
            String autor = currentUser.getUid();
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DocumentReference autorRef = db.collection("autores").document(uid);
            relato relato = new relato(titulo, genresText, autorRef.getPath(),contenido);

            Map<String, Object> relatoMap = new HashMap<>();
            relatoMap.put("titulo", relato.getTitulo().toUpperCase());
            relatoMap.put("contenido", relato.getDescripción());
            relatoMap.put("autor", autorRef);
            relatoMap.put("estado", false);
            relatoMap.put("genero", relato.getGenero());
            relatoMap.put("puntuacion", 0);
            relatoMap.put("genero_1", genero_1);
            relatoMap.put("genero_2", genero_2);
            relatoMap.put("genero_3", genero_3);

            relatosRef.add(relatoMap)
                    .addOnSuccessListener(documentReference -> {
                        Log.d(TAG, "Relato añadido con ID: " + documentReference.getId());
                    })
                    .addOnFailureListener(e -> {
                        Log.w(TAG, "Error añadiendo el relato", e);
                    });
        } else {
            // No hay usuario autenticado, hacer algo en consecuencia
        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}