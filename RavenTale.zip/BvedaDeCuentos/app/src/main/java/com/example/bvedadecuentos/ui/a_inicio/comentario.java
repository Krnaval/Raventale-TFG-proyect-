package com.example.bvedadecuentos.ui.a_inicio;

public class comentario {
    private String usuario;
    private String comentario;
    private float puntuacion;

    public comentario(String usuario, String comentario, float puntuacion) {
        this.usuario = usuario;
        this.comentario = comentario;
        this.puntuacion = puntuacion;
    }



    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }


    public void setComentario(String comentario) {
        this.comentario = comentario;
    }



    public void setPuntuacion(float puntuacion) {
        this.puntuacion = puntuacion;
    }
}