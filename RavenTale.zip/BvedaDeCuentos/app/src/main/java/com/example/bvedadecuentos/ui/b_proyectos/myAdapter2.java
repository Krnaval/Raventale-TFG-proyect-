package com.example.bvedadecuentos.ui.b_proyectos;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bvedadecuentos.R;

import java.util.ArrayList;

public class myAdapter2 extends RecyclerView.Adapter<myAdapter2.MyHolder>{

    private ArrayList imagenesLibrosPortada;
    private Context contexto;
    private String actuar;

    public myAdapter2(ArrayList<String>arr, Context context, String actuar){
        //FUNCIONA
        imagenesLibrosPortada = arr;
        contexto = context;
        this.actuar = actuar;



    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(contexto).inflate(R.layout.lista_libros, parent, false);
        System.out.println("ESTIC AIXI");
        Log.d("myAdapter", "Tamaño de la lista de imágenes: " + imagenesLibrosPortada.size());
        System.out.println("ESTIC AIXI");
        return new MyHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        String imagen = imagenesLibrosPortada.get(position).toString();
        System.out.println("ESTIC AIXI"+imagen);
        holder.tx.setText(imagen);
        if (actuar.toString().equalsIgnoreCase("publicar")){

            //MIRAMOS LA BASE DE DATOS, SI EL LIBRO PULSADO ESTÁ SIN PUBLICAR
            holder.tx.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(contexto);
                    builder.setMessage("¿Está seguro de que desea publicar este libro?")
                            .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Acción a realizar si se confirma la publicación del libro
                                    Toast.makeText(contexto, "Libro publicado: " + holder.tx.getText(), Toast.LENGTH_SHORT).show();

                                    //CAMBIARLO EN LA BASE DE DATOS


                              }
                            })
                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Acción a realizar si se cancela la publicación del libro
                                    dialog.cancel();
                                }
                            });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            });

            //EN EL CASO CONTRARIO


        }else if (actuar.equalsIgnoreCase("escribir")){
            holder.tx.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent= new Intent(contexto, listarRelatos.class);
                    contexto.startActivity(intent);
                }
            });
            System.out.println("A");
        }
    }

    @Override
    public int getItemCount() {
        System.out.printf("55555555555555555555555555555555555555555555555");
        System.out.println(imagenesLibrosPortada.size());
        return imagenesLibrosPortada.size();
    }

    class MyHolder extends RecyclerView.ViewHolder{
        TextView tx;
        ImageView iv;
        public MyHolder (@NonNull View itemView){
            super(itemView);
            tx = itemView.findViewById(R.id.textViewTitle);
            //iv = itemView.findViewById(R.id.imageView2);
        }
    }

}
