package com.example.bvedadecuentos.ui.a_inicio;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;


import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.databinding.FragmentInicioBinding;


public class InicioFragment extends Fragment {

    private FragmentInicioBinding binding;
    ImageButton autor, relato, puntuacion, genero;
    EditText search_edit_text;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentInicioBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        autor = root.findViewById(R.id.search_button2);
        relato = root.findViewById(R.id.search_button3);
        genero = root.findViewById(R.id.search_button4);
        puntuacion = root.findViewById(R.id.search_button5);

        search_edit_text = root.findViewById(R.id.search_edit_text);

        autor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirstFragment firstFragment = new FirstFragment();

                Bundle args = new Bundle();
                args.putString("message", search_edit_text.getText().toString());
                firstFragment.setArguments(args);


                getChildFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragmentContainerView2, firstFragment)
                        .addToBackStack(null)
                        .commit();

            }
        });


        relato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SecondFragment SecondFragment = new SecondFragment();


                Bundle args = new Bundle();
                args.putString("message", search_edit_text.getText().toString());
                SecondFragment.setArguments(args);

                getChildFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragmentContainerView2, SecondFragment)
                        .addToBackStack(null)
                        .commit();
            }
        });

        genero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThreeFragment ThreeFragment = new ThreeFragment();

                Bundle args = new Bundle();
                args.putString("message", search_edit_text.getText().toString());
                ThreeFragment.setArguments(args);


                getChildFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragmentContainerView2, ThreeFragment)
                        .addToBackStack(null)
                        .commit();


            }
        });

        puntuacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FourFragment FourFragment = new FourFragment();

                Bundle args = new Bundle();
                args.putString("message", search_edit_text.getText().toString());
                FourFragment.setArguments(args);


                getChildFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragmentContainerView2, FourFragment)
                        .addToBackStack(null)
                        .commit();


            }
        });




        return root;
    }
}