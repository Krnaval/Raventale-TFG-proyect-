package com.example.bvedadecuentos.ui.a_inicio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;

import com.example.bvedadecuentos.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

public class lector extends AppCompatActivity {

    static TextView titulo, contenido;
    String generosRelato;
    String nombreRelato;
    String autorRelato;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lector);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        titulo = findViewById(R.id.TextViewTitulo);
        contenido = findViewById(R.id.TextViewContenido);
        titulo.setText("");
        contenido.setText("");
        contenido.setMovementMethod(new ScrollingMovementMethod());


        System.out.println("AAAAAAAAAAAAAAAAWAWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
        Intent intent = getIntent();
        nombreRelato = intent.getStringExtra("titulo");
        autorRelato = intent.getStringExtra("autor");
        System.out.println(nombreRelato+"  "+generosRelato+"  "+autorRelato);
        if (nombreRelato != null) {
            titulo.setFocusable(false);
            titulo.setFocusableInTouchMode(false);
            titulo.setClickable(false);
            System.out.println("AAAAAAAAAAAAAAAAWAWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");

        }

        if (nombreRelato != null) {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            CollectionReference relatosRef = db.collection("relatos");
            DocumentReference autorRef = db.collection("autores").document(autorRelato);
            relatosRef.whereEqualTo("titulo", nombreRelato.toUpperCase())
                    .whereEqualTo("autor", autorRef).get()
                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                        @Override
                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                            System.out.println("AAAAAAAAAAAAAAAAWAWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");

                            if (!queryDocumentSnapshots.isEmpty()) {

                                System.out.println("AAAAAAAAAAAAAAAAWAWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");

                                // Si encontró el libro en la base de datos, actualiza los EditText con sus datos
                                String tituloLibro = queryDocumentSnapshots.getDocuments().get(0).getString("titulo");
                                String contenidoLibro = queryDocumentSnapshots.getDocuments().get(0).getString("contenido");
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        titulo.setText(tituloLibro);
                                        contenido.setText(contenidoLibro);
                                    }
                                });
                            }
                        }
                    });

        }


    }
    @Override
    public void onBackPressed() {
        // Llamar al método finish() para cerrar esta actividad
        finish();
    }
}