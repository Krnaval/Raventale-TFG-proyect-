package com.example.bvedadecuentos.ui.d_eventos;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.util.Log;
import android.view.MotionEvent;
import androidx.core.view.MotionEventCompat;

import androidx.annotation.NonNull;
import androidx.core.view.MotionEventCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.databinding.FragmentEventsBinding;

import java.io.IOException;


public class EventsFragment extends Fragment {

    private FragmentEventsBinding binding;
    MediaPlayer md;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        binding = FragmentEventsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textEvents;
        md = MediaPlayer.create(getContext(), R.raw.buttonsound);
        comprobarSonido();

        return root;

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void comprobarSonido(){
        if (md != null){
            md.stop();
            try {
                md.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        md.start();
    }


}