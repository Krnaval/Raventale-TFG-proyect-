package com.example.bvedadecuentos;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;


public class login_complete extends AppCompatActivity {
    MediaPlayer md;
    ArrayList<String> citas = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_complete);
        getSupportActionBar().hide();


        //Establecemos que en nuestra pantalla no mostremos ni la barra del pograma ni de las notificaciones. Además de esconder la barra de navegación
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        md = MediaPlayer.create(this, R.raw.raven_sing);
        md.start();

        citas.add("Muestranos tu arte, escribe.");
        citas.add("¡Donde y cuando quieras!");
        citas.add("«Conoce de ante mano el efecto que deseas»\n—Edgar Allan Poe");
        citas.add("Sin miedo a expresarte, \n¡Estás entre cuervos!");
        citas.add("Se aprende más leyendo que escribiendo.");
        citas.add("«La escritura es la pintura de la voz»\n—Vontaire.");
        citas.add("Emborrachate de literatura... \n¡pues la resaca es cultura!");
        citas.add("No importa el genero. \nEscribe de lo que gustes.");
        citas.add("Bienvenido a nuestro nido, se libre de expresarte.");
        citas.add("«Si usas diálogos, dilos en voz alta mientras los escribes»\n—John Steinbeck");
        citas.add("Emocionate. Es tu momento.");
        citas.add("Aquí todos somos una bandada, avisanos de una mala conducta");
        citas.add("Si te gusta nuestra app, ¡que tus amigos se unan a la bandada!");

        TextView cit = findViewById(R.id.textView18);
        Random r = new Random();
        String citaAleatoria = citas.get(r.nextInt(citas.size()));
        cit.setText(citaAleatoria);

        cit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String citaAleatoria = citas.get(r.nextInt(citas.size()));
                cit.setText(citaAleatoria);
            }
        });

        /**
         * Crearemos un proceso. Dicho proceso servirá para esperar hasta que termine el tiempo.
         * El tiempo está medido con el Timer, y con el pasamos la tarea que tiene que ejercer una vez pase el tiempo
         * En este caso, tiene 6.5 segundos para iniciar la tarea.
         * Una vez iniciamos la tarea (con el run) hacemos un intent a la clase que será la principal. El menú
         */
        TimerTask tarea = new TimerTask() {
        @Override
        //Inicio del cambio al menu
        public void run() {
            Intent intent = new Intent(login_complete.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    };
        //Temporizador (6.5 seg)
        Timer tiempo = new Timer();
        tiempo.schedule(tarea, 7000);


}
}