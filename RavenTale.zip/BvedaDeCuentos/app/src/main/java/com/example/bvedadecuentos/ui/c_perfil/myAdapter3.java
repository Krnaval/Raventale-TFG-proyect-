package com.example.bvedadecuentos.ui.c_perfil;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.ui.relato;

import java.util.ArrayList;

public class myAdapter3 extends RecyclerView.Adapter<myAdapter3.MyHolder>{

    private ArrayList<relato> listaRelatos = new ArrayList<>();
    private Context contexto;

    public myAdapter3(ArrayList< relato>arr, Context context){
            //FUNCIONA
            listaRelatos = arr;
            contexto = context;


        }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(contexto).inflate(R.layout.libros2, parent, false);
        System.out.println("ESTIC AIXI");
        Log.d("myAdapter", "Tamaño de la lista de imágenes: " + listaRelatos.size());
        System.out.println("ESTIC EN EL ADAPTER3");
        return new MyHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        String titulo = listaRelatos.get(position).getTitulo();
        titulo = titulo.replaceAll(" ", "\n"); // Reemplazar espacios en blanco con saltos de línea
        holder.titulo.setText(titulo);        holder.valoracion.setText(String.valueOf(listaRelatos.get(position).getPuntuación()));
        System.out.println("A");

    }

    @Override
    public int getItemCount() {
        System.out.printf("55555555555555555555555555555555555555555555555");
        System.out.println(listaRelatos.size());
        return listaRelatos.size();
    }

    class MyHolder extends RecyclerView.ViewHolder{
        TextView titulo;
        TextView valoracion;
        public MyHolder (@NonNull View itemView){
            super(itemView);
            titulo = itemView.findViewById(R.id.textViewTitle);
            valoracion = itemView.findViewById(R.id.textViewval);
        }
    }
}
