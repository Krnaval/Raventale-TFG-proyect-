package com.example.bvedadecuentos.ui.c_perfil;

import static android.app.Activity.RESULT_OK;
import static android.content.ContentValues.TAG;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.bvedadecuentos.R;
import com.example.bvedadecuentos.databinding.FragmentPerfilBinding;
import com.example.bvedadecuentos.ui.relato;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import de.hdodenhof.circleimageview.CircleImageView;

public class perfilFragment extends Fragment {

    private FragmentPerfilBinding binding;
    private RecyclerView recyclerModelo;
    private RecyclerView perfil_public;
    private RecyclerView perfil_better;

    private TextView nombre, descr;


    private LinearLayoutManager linearLayoutManager;
    private LinearLayoutManager linearLayoutManager2;
    private LinearLayoutManager linearLayoutManager3;


    private myAdapter adapter;
    private myAdapter2 adapter2;
    private myAdapter3 adapter3;
    private Button options;    private FirebaseAuth aut;

    ArrayList imagenes;
    public static final String LOGIN = "login";
    MediaPlayer md;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentPerfilBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        FirebaseStorage storage = FirebaseStorage.getInstance();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        StorageReference storageRef = storage.getReference();
        String storagePath = "autores/" + uid + "/imagen.jpg";
        StorageReference imageRef = storageRef.child(storagePath);

        imageRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Glide.with(getContext())
                        .load(uri)
                        .override(305, 183)
                        .centerCrop()
                        .override(300, 300)
                        .into(binding.profileImage);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                binding.profileImage.setImageResource(R.drawable.iconnav);
            }
        });

        md = MediaPlayer.create(getContext(), R.raw.buttonsound);

        SharedPreferences login = getContext().getSharedPreferences(LOGIN, Context.MODE_PRIVATE);

        nombre = root.findViewById(R.id.textViewNombre);
        nombre.setText(login.getString("Name", "No se carga bien el usu"));
        descr = root.findViewById(R.id.textView5);
        descr.setText(login.getString("Descr", ""));

        Drawable drawable = getResources().getDrawable(R.drawable.imagess);

        recyclerModelo = root.findViewById(R.id.perfil);
        recyclerModelo.setHasFixedSize(true);
        linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        recyclerModelo.setLayoutManager(linearLayoutManager);

        ArrayList<relato> relatos = new ArrayList<>();

        CollectionReference relatosRef = db.collection("relatos");
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = auth.getCurrentUser();
        System.out.println("NAZI");


        if (currentUser != null) {
            System.out.println("ENTRE");
            DocumentReference autorRef = db.collection("autores").document(uid);
            System.out.println("EXISTO CON EL DOC "+autorRef.getPath());
            Query query = relatosRef.whereEqualTo("autor", autorRef);

            query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@org.checkerframework.checker.nullness.qual.NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful()) {
                        // la consulta se ejecutó correctamente, recorre los documentos resultantes
                        System.out.println("ESTOY AQUI 1");
                        if (task.getResult().isEmpty()) {
                            System.out.println("Hay " + task.getResult().size() + " documentos que cumplen con el filtro.");
                            System.out.println(autorRef);
                        }
                        for (DocumentSnapshot document : task.getResult().getDocuments()) {
                            System.out.println("ESTOY AQUI 2");
                            // obtén los campos del documento y haz lo que necesites con ellos
                            String titulo = document.getString("titulo");


                            // crea un objeto "relato" con los campos del documento y agrega a la lista de relatos del autor
                            relato relato = new relato(titulo, drawable);
                            relatos.add(relato);
                            System.out.println(relatos.size());
                            System.out.println(relatos.get(0).getAutor());
                            adapter = new myAdapter(relatos, getContext());
                            recyclerModelo.setAdapter(adapter);

                        }

                        // haz lo que necesites con la lista de relatos del autor
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());
                    }
                }
            });
            ArrayList<relato> relatos2 = new ArrayList<>();

            perfil_public = root.findViewById(R.id.perfil_public);
            perfil_public.setHasFixedSize(true);
            //Cargar recyclerView Con datos
            linearLayoutManager2 = new LinearLayoutManager(perfilFragment.this.getContext(), LinearLayoutManager.HORIZONTAL, false);
            perfil_public.setLayoutManager(linearLayoutManager2);
            query = relatosRef.whereEqualTo("autor", autorRef).whereEqualTo("estado", true);

            query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@org.checkerframework.checker.nullness.qual.NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful()) {
                        // la consulta se ejecutó correctamente, recorre los documentos resultantes
                        System.out.println("ESTOY AQUI 1");
                        if (task.getResult().isEmpty()) {
                            System.out.println("Hay " + task.getResult().size() + " documentos que cumplen con el filtro.");
                            System.out.println(autorRef);
                        }
                        for (DocumentSnapshot document : task.getResult().getDocuments()) {
                            System.out.println("ESTOY AQUI 2");
                            // obtén los campos del documento y haz lo que necesites con ellos
                            String titulo = document.getString("titulo");


                            // crea un objeto "relato" con los campos del documento y agrega a la lista de relatos del autor
                            relato relato = new relato(titulo, drawable);
                            relatos2.add(relato);
                            System.out.println(relatos2.size());
                            System.out.println(relatos2.get(0).getAutor());
                            adapter2 = new myAdapter2(relatos2, getContext());
                            perfil_public.setAdapter(adapter2);

                        }

                        // haz lo que necesites con la lista de relatos del autor
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());
                    }
                }
            });

            ArrayList<relato> relatos3 = new ArrayList<>();
            ArrayList<DocumentSnapshot> documentos = new ArrayList<>();
            perfil_better = root.findViewById(R.id.perfil_better);
            perfil_better.setHasFixedSize(true);
            //Cargar recyclerView Con datos
            linearLayoutManager3 = new LinearLayoutManager(perfilFragment.this.getContext(), LinearLayoutManager.HORIZONTAL, false);
            perfil_better.setLayoutManager(linearLayoutManager3);
            query = relatosRef
                    .whereEqualTo("autor", autorRef)
                    .whereEqualTo("estado", true); // ordenar por valoración de mayor a menor

            query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@org.checkerframework.checker.nullness.qual.NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful()) {
                        // la consulta se ejecutó correctamente, recorre los documentos resultantes
                        System.out.println("ESTOY AQUI 1");
                        if (task.getResult().isEmpty()) {
                            System.out.println("Hay " + task.getResult().size() + " documentos que cumplen con el filtro.");
                            System.out.println(autorRef);
                        }

                        for (DocumentSnapshot document : task.getResult()) {
                            documentos.add(document);
                        }

                        Collections.sort(documentos, new Comparator<DocumentSnapshot>() {
                            @Override
                            public int compare(DocumentSnapshot d1, DocumentSnapshot d2) {
                                double puntuacion1 = d1.getDouble("puntuacion");
                                double puntuacion2 = d2.getDouble("puntuacion");
                                return Double.compare(puntuacion2, puntuacion1);
                            }
                        });

                        ArrayList<relato> relatosOrdenados = new ArrayList<>();
                        for (DocumentSnapshot document : documentos) {
                            String titulo = document.getString("titulo");
                            int puntuacion = document.getLong("puntuacion").intValue();
                            relato relato = new relato(titulo, puntuacion);
                            relatosOrdenados.add(relato);
                        }

                        // Crea y configura el adaptador y el RecyclerView con la lista de relatos ordenados
                        adapter3 = new myAdapter3(relatosOrdenados, getContext());
                        perfil_better.setAdapter(adapter3);
                        // haz lo que necesites con la lista de relatos del autor
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());
                    }
                }
            });
        }


        //CREAMOS EL CLICK LISTENER DE LA IMAGEN
        CircleImageView image = binding.profileImage;
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    // Permission is not granted
                    ActivityCompat.requestPermissions(requireActivity(),
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            1);
                } else {
                    // Permission has already been granted
                    openGallery();
                }

            }
        });


        comprobarSonido();

        return root;
    }




    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(intent, 2);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == 2) {
            Uri selectedImageUri = data.getData();
            binding.profileImage.setImageURI(selectedImageUri);

            ProgressDialog progressDialog = new ProgressDialog(getContext());
            progressDialog.setMessage("Subiendo imagen...");
            progressDialog.setCancelable(false);
            progressDialog.show();

            getActivity().getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            FirebaseStorage storage = FirebaseStorage.getInstance();
            StorageReference storageRef = storage.getReference();
            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            String storagePath = "autores/" + uid + "/imagen.jpg";
            StorageReference imageRef = storageRef.child(storagePath);
            imageRef.putFile(selectedImageUri)
                    .addOnSuccessListener(taskSnapshot -> {
                        // Obtener la URL de descarga de la imagen
                        imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                            // Guardar la URL en la base de datos de Firebase Firestore
                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                            DocumentReference userRef = db.collection("autores").document(uid);
                            userRef.get().addOnCompleteListener(task -> {
                                if (task.isSuccessful() && task.getResult() != null) {
                                    DocumentSnapshot document = task.getResult();
                                    if (document.exists()) {
                                        userRef.update("profileImageUrl", uri.toString())
                                                .addOnSuccessListener(aVoid -> {
                                                    progressDialog.dismiss();
                                                    Toast.makeText(getContext(), "Imagen subida correctamente", Toast.LENGTH_SHORT).show();
                                                    // Habilitar interacción del usuario con la pantalla
                                                    getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                                                })
                                                .addOnFailureListener(e -> {
                                                    progressDialog.dismiss();
                                                    Toast.makeText(getContext(), "Error al guardar la URL de la imagen", Toast.LENGTH_SHORT).show();
                                                    // Habilitar interacción del usuario con la pantalla
                                                    getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                                                });
                                    } else {
                                        progressDialog.dismiss();
                                        Toast.makeText(getContext(), "No existe el usuario en la base de datos", Toast.LENGTH_SHORT).show();
                                        // Habilitar interacción del usuario con la pantalla
                                        getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                                    }
                                } else {
                                    progressDialog.dismiss();
                                    Toast.makeText(getContext(), "Error al obtener el usuario de la base de datos", Toast.LENGTH_SHORT).show();
                                    // Habilitar interacción del usuario con la pantalla
                                    getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                                }
                            });
                        });
                    })
                    .addOnFailureListener(e -> Toast.makeText(getContext(), "Error al subir la imagen", Toast.LENGTH_SHORT).show());
            getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        }
    }




    //REFRESCAR CUANDO VOLVAMOS
    @Override
    public void onResume() {
        super.onResume();

        // Refrescamos los datos del perfil
        SharedPreferences login = getContext().getSharedPreferences(LOGIN, Context.MODE_PRIVATE);
        nombre.setText(login.getString("Name", "No se carga bien el usu"));
        descr.setText(login.getString("Descr", ""));
    }

    private void comprobarSonido(){
        if (md != null){
            md.stop();
            try {
                md.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        md.start();
    }



}