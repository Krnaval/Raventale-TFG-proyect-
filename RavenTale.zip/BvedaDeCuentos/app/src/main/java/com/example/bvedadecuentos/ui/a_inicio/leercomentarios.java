package com.example.bvedadecuentos.ui.a_inicio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.bvedadecuentos.R;

public class leercomentarios extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leercomentarios);
    }
}